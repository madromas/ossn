<?php
/**
 *    OpenSource-SocialNetwork
 *
 * @package   (webbehinds.com).ossn
 * @author    OSSN Core Team | Sathish Kumar <info@opensource-socialnetwork.com>
 * @copyright 2014 webbehinds
 * @license   General Public Licence http://opensource-socialnetwork.com/licence
 * @link      http://www.opensource-socialnetwork.com/licence
 */
$ru = array(
    'contact' => 'Обратная связь',
	
	'contact:title' => 'Обратная связь',
	'contact:description' => 'Пожалуйста, заполните все поля',
	'contact:name' => 'Ваше имя',
	'contact:email' => 'Ваш Email',
	'contact:message' => 'Сообщение',
	'contact:send' => 'Отправить',
	
	'contact:save' => 'Сохранить',
	'contact:recieve' => 'Введите адрес электронной почты, на который вы хотите получить отзыв',
	
	'contact:text:name' => 'Ваше полное имя',
	'contact:text:email' => 'Действительный адрес электронной почты',
	'contact:text:message' => 'Ваше сообщение',
	
	'contact:not:sent' => 'Сообщение не было отправлено',
	'contact:sent' => 'Ура, сообщение было отправлено!',
	'contact:details' => 'Пожалуйста, заполните все поля',
	
	'settings:saved' => 'Настройки сохранены',
	'settings:not:saved' => 'Невозможно сохранить настройки',
	'settings:value' => 'Заполните все значения',
	
	'contact:body' => '
	 Имя 	: %s
     E-mail 	: %s
	 
     Сообщение  : %s ',
);
ossn_register_languages('ru', $ru); 
