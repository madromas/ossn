<?php
/**
 *    OpenSource-SocialNetwork
 *
 * @package   (webbehinds.com).ossn
 * @author    OSSN Core Team | Sathish Kumar <info@opensource-socialnetwork.com>
 * @copyright 2014 webbehinds
 * @license   General Public Licence http://opensource-socialnetwork.com/licence
 * @link      http://www.opensource-socialnetwork.com/licence
 */
$en = array(
    'contact' => 'Contact Us',

    'contact:title' => 'Contact Us',
	'contact:description' => 'Please fill all the texts in the fields',
	'contact:name' => 'Your Name',
	'contact:email' => 'Your Email',
	'contact:message' => 'Message',
	'contact:send' => 'Send',
	
	'contact:save' => 'Save',
	'contact:recieve' => 'Enter the email that you want to receive feedback',
	
	'contact:text:name' => 'Your Full Name',
	'contact:text:email' => 'Valid Email Adress',
	'contact:text:message' => 'Your Message to Us',
	
	'contact:not:sent' => 'Message has not been sent',
	'contact:sent' => 'Message has been sent!',
	'contact:details' => 'Please fill all the details',
	
	'settings:saved' => 'Settings saved',
	'settings:not:saved' => 'Cannot save settings',
	'settings:value' => 'Please Enter the value',
	
	'contact:body' => '
	 Name 	: %s
     E-mail 	: %s	
	 
     Message  : %s ',
);
ossn_register_languages('en', $en); 
