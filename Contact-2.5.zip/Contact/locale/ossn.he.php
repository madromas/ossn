<?php
/**
 * Open Source Social Network
 *
 * @package   Open Source Social Network
 * @author    Open Social Website Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */
$he = array(
'contact' => 'Contact Us',

    'contact:title' => 'Contact Us',
	'contact:description' => 'Please fill all the texts in the fields',
	'contact:name' => 'Your Name',
	'contact:email' => 'Your Email',
	'contact:message' => 'Message',
	'contact:send' => 'Send',
	
	'contact:save' => 'Save',
	'contact:recieve' => 'Enter the email that you want to receive feedback',
	
	'contact:text:name' => 'Your Full Name',
	'contact:text:email' => 'Valid Email Adress',
	'contact:text:message' => 'Your Message to Us',
	
	'contact:not:sent' => 'Message has not been sent',
	'contact:sent' => 'Message has been sent!',
	'contact:details' => 'Please fill all the details',
	
	'settings:saved' => 'Settings saved',
	'settings:not:saved' => 'Cannot save settings',
	'settings:value' => 'Please Enter the value',
	
	'contact:body' => '
	 Name 	: %s
     E-mail 	: %s	
	 
     Message  : %s ',
);
ossn_register_languages('he', $he); 
