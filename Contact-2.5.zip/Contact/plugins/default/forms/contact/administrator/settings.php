<div>
<label><?php echo ossn_print('contact:title'); ?></label>
<label><?php echo ossn_print('contact:recieve'); ?></label>
<input type="text" name="email" value="<?php echo $params['settings']->email;?>"/>
<!--<textarea id="gmap" name="gmap" placeholder="Enter Your google map iframe" ><?php //echo $params['settings']->gmap;?></textarea>-->
<input type="submit" class="ossn-admin-button btn btn-success" value="<?php echo ossn_print('contact:save'); ?>"/>
</div>






