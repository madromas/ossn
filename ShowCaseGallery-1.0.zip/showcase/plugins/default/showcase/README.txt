Upload Images to /gallery

Thumbnails are created automatically.

You can Replace js/showcase.php, css/showcase.php and showcase/showcase.php with your own gallery that fits your needs. 

